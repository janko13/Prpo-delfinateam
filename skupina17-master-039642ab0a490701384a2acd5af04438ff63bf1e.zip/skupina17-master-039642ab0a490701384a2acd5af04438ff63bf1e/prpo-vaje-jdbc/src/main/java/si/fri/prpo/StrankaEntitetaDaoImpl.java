package si.fri.prpo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import si.fri.prpo.Entiteta;
import si.fri.prpo.Stranka;

public class StrankaEntitetaDaoImpl implements BaseDao{
	
	@Override
	public Connection getConnection(){
		Connection connection = null;
		DataSource dataSource = null;
		try {
			Context initCtx = new InitialContext();
			dataSource = (DataSource) initCtx.lookup("java:/PostgresDS");
		} catch(NamingException e){
			e.printStackTrace();
		}
		try {
			connection = dataSource.getConnection();
		} catch(SQLException e){
			e.printStackTrace();
		}
		return connection;
	}

	@Override
	public Entiteta vrni(int id){
		Entiteta entiteta = null;
		Connection connection = getConnection();
		PreparedStatement pStatement = null;
		try {
			String s = "SELECT * FROM stranka WHERE id = ?";
			pStatement = connection.prepareStatement(s);
			pStatement.setInt(1, id);
			ResultSet resultSet = pStatement.executeQuery(s);
			while(resultSet.next()) {
					entiteta = new Stranka(resultSet.getInt(1), resultSet.getString(2),resultSet.getString(3), resultSet.getString(4), resultSet.getString(5));
			}
		} catch(SQLException e){
			e.printStackTrace();
		}/* finally {
			if (pStatement != null) {
				try {
					pStatement.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
		return entiteta;
	}

	@Override
	public void vstavi(Entiteta ent) {
		Connection connection = getConnection();
		PreparedStatement pStatement = null;
		try {
			String s = "INSERT INTO stranka('id', 'ime', 'priimek', 'uporabnisko_ime', 'email') VALUES (?, ?, ?, ?, ?, ?)";
			pStatement = connection.prepareStatement(s);
			pStatement.setInt(1, ((Stranka)ent).getId());
			pStatement.setString(2, ((Stranka)ent).getIme());
			pStatement.setString(3, ((Stranka)ent).getPriimek());
			pStatement.setString(4, ((Stranka)ent).getUporabnisko_ime());
			pStatement.setString(5, ((Stranka)ent).getEmail());
			pStatement.executeUpdate();
		} catch(SQLException e){
			e.printStackTrace();
			System.out.println("Napaka pri vstavljanju stranke.");
		} /*finally {
			if (statement != null) {
				try {
					statement.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
	}

	@Override
	public void odstrani(int id){
		Connection connection = getConnection();
		PreparedStatement pStatement = null;
		try {
			String s = "DELETE FROM stranka WHERE id = ?";
			pStatement = connection.prepareStatement(s);
			pStatement.setInt(1, id);
			pStatement.executeUpdate();
		} catch(SQLException e){
			e.printStackTrace();
			System.out.println("Napaka pri brisanju iz baze.");
		} /*finally {
			if (pStatement != null) {
				try {
					pStatement.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
	}

	@Override
	public void posodobi(Entiteta ent){
		Connection connection = getConnection();
		PreparedStatement pStatement = null;
		try {
			String s = "UPDATE stranka SET id = ?, ime = ?, priimek = ?, uporabnisko_ime = ?, email = ? WHERE id = ?";
			pStatement = connection.prepareStatement(s);
			pStatement.setInt(1, ((Stranka)ent).getId());
			pStatement.setString(2, ((Stranka)ent).getIme());
			pStatement.setString(3, ((Stranka)ent).getPriimek());
			pStatement.setString(4, ((Stranka)ent).getUporabnisko_ime());
			pStatement.setString(5, ((Stranka)ent).getEmail());
			pStatement.setInt(7, ((Stranka)ent).getId());
			pStatement.executeUpdate();
		} catch(SQLException e){
			 System.out.println("Napaka pri posodabljanju stranke.");
			 e.printStackTrace();
		} /*finally {
			if (pStatement != null) {
				try {
					pStatement.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
	}
	
	@Override
	public List<Entiteta> vrniVse(){
		Connection connection = getConnection();
		PreparedStatement pStatement = null;
		List<Entiteta> list = new LinkedList<Entiteta>();
		try {
			String s = "SELECT * FROM stranka"; 
			pStatement = connection.prepareStatement(s);
			ResultSet resultSet = pStatement.executeQuery();
			//System.out.println("Tuki sm!");
			while(resultSet.next()){
				list.add(new Stranka(resultSet.getInt("id"), resultSet.getString("ime"), resultSet.getString("priimek"), resultSet.getString("uporabnisko_ime"), resultSet.getString("email")));
			} 
		} catch(SQLException e){
			 System.out.println("Napaka v poizvedbi.");
			 e.printStackTrace();
		}/* finally {
			if (pStatement != null) {
				try {
					pStatement.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
		return list;
	}
}
