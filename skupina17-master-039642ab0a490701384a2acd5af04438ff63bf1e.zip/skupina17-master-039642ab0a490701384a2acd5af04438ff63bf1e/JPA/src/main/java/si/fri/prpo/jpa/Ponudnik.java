package si.fri.prpo.jpa;
import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the ponudnik database table.
 * 
 */
@Entity
@NamedQuery(name="Ponudnik.findAll", query="SELECT p FROM Ponudnik p")
public class Ponudnik implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;

	private String lokacija;

	private String naziv;

	//bi-directional many-to-one association to Storitev
	@OneToMany(mappedBy="ponudnikBean")
	private List<Storitev> storitevs;

	//bi-directional many-to-one association to Ugodnost
	@OneToMany(mappedBy="ponudnikBean")
	private List<Ugodnost> ugodnosts;

	//bi-directional many-to-one association to ZbraneTocke
	@OneToMany(fetch = FetchType.LAZY, mappedBy="ponudnikBean", cascade = CascadeType.ALL)
	private List<ZbraneTocke> zbraneTockes;

	public Ponudnik() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLokacija() {
		return this.lokacija;
	}

	public void setLokacija(String lokacija) {
		this.lokacija = lokacija;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public List<Storitev> getStoritevs() {
		return this.storitevs;
	}

	public void setStoritevs(List<Storitev> storitevs) {
		this.storitevs = storitevs;
	}

	public Storitev addStoritev(Storitev storitev) {
		getStoritevs().add(storitev);
		storitev.setPonudnikBean(this);

		return storitev;
	}

	public Storitev removeStoritev(Storitev storitev) {
		getStoritevs().remove(storitev);
		storitev.setPonudnikBean(null);

		return storitev;
	}

	public List<Ugodnost> getUgodnosts() {
		return this.ugodnosts;
	}

	public void setUgodnosts(List<Ugodnost> ugodnosts) {
		this.ugodnosts = ugodnosts;
	}

	public Ugodnost addUgodnost(Ugodnost ugodnost) {
		getUgodnosts().add(ugodnost);
		ugodnost.setPonudnikBean(this);

		return ugodnost;
	}

	public Ugodnost removeUgodnost(Ugodnost ugodnost) {
		getUgodnosts().remove(ugodnost);
		ugodnost.setPonudnikBean(null);

		return ugodnost;
	}

	public List<ZbraneTocke> getZbraneTockes() {
		return this.zbraneTockes;
	}

	public void setZbraneTockes(List<ZbraneTocke> zbraneTockes) {
		this.zbraneTockes = zbraneTockes;
	}

	public ZbraneTocke addZbraneTocke(ZbraneTocke zbraneTocke) {
		getZbraneTockes().add(zbraneTocke);
		zbraneTocke.setPonudnikBean(this);

		return zbraneTocke;
	}

	public ZbraneTocke removeZbraneTocke(ZbraneTocke zbraneTocke) {
		getZbraneTockes().remove(zbraneTocke);
		zbraneTocke.setPonudnikBean(null);

		return zbraneTocke;
	}

}