package si.fri.prpo.jpa;
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the storitev database table.
 * 
 */
@Entity
@NamedQuery(name="Storitev.findAll", query="SELECT s FROM Storitev s")
public class Storitev implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;

	private String naziv;

	@Column(name="stevilo_pridobljenih_tock")
	private int steviloPridobljenihTock;

	//bi-directional many-to-one association to Ponudnik
	@ManyToOne
	@JoinColumn(name="ponudnik")
	private Ponudnik ponudnikBean;

	public Storitev() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public int getSteviloPridobljenihTock() {
		return this.steviloPridobljenihTock;
	}

	public void setSteviloPridobljenihTock(int steviloPridobljenihTock) {
		this.steviloPridobljenihTock = steviloPridobljenihTock;
	}

	public Ponudnik getPonudnikBean() {
		return this.ponudnikBean;
	}

	public void setPonudnikBean(Ponudnik ponudnikBean) {
		this.ponudnikBean = ponudnikBean;
	}

}