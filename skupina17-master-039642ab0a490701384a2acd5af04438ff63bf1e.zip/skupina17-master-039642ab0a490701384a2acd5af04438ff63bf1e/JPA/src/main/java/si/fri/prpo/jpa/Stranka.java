package si.fri.prpo.jpa;
import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.Cascade;

import java.util.List;


/**
 * The persistent class for the stranka database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name="Stranka.findAll", query="SELECT s FROM Stranka s"),
	@NamedQuery(name="Stranka.findByName", query="SELECT s FROM Stranka s WHERE s.ime LIKE :sName"),
	@NamedQuery(name="Stranka.findByLastname", query="SELECT s FROM Stranka s WHERE s.priimek LIKE :sLastname"),
	@NamedQuery(name="Stranka.findByEmail", query="SELECT s FROM Stranka s WHERE s.email LIKE :sEmail")
})
public class Stranka implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;

	@Column(name="email")
	private String email;

	@Column(name="ime")
	private String ime;

	@Column(name="priimek")
	private String priimek;

	@Column(name="uporabnisko_ime")
	private String uporabniskoIme;

	//bi-directional many-to-one association to ZbraneTocke
	@OneToMany(fetch=FetchType.LAZY, mappedBy="strankaBean", cascade = CascadeType.ALL)
	private List<ZbraneTocke> zbraneTockes;

	public Stranka() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIme() {
		return this.ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPriimek() {
		return this.priimek;
	}

	public void setPriimek(String priimek) {
		this.priimek = priimek;
	}

	public String getUporabniskoIme() {
		return this.uporabniskoIme;
	}

	public void setUporabniskoIme(String uporabniskoIme) {
		this.uporabniskoIme = uporabniskoIme;
	}

	public List<ZbraneTocke> getZbraneTockes() {
		return this.zbraneTockes;
	}

	public void setZbraneTockes(List<ZbraneTocke> zbraneTockes) {
		this.zbraneTockes = zbraneTockes;
	}

	public ZbraneTocke addZbraneTocke(ZbraneTocke zbraneTocke) {
		getZbraneTockes().add(zbraneTocke);
		zbraneTocke.setStrankaBean(this);

		return zbraneTocke;
	}

	public ZbraneTocke removeZbraneTocke(ZbraneTocke zbraneTocke) {
		getZbraneTockes().remove(zbraneTocke);
		zbraneTocke.setStrankaBean(null);

		return zbraneTocke;
	}

}