package si.fri.prpo.zrna;

import java.util.List;
import si.fri.prpo.jpa.Stranka;

import javax.ejb.Local;

@Local
public interface UpravljalecStrankSBLocal {
	
	public void shraniNovoStranko(Stranka stranka);
	
	public Stranka vrniStranko(String uporabniskoIme);
	
	public Stranka vrniStranko(int id);

	public void odstraniStranko(String uporabniskoIme);
	
	public void odstraniStranko(int id);
	
	public List<Stranka> vrniVseStranke();

}
