package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.Local;

import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;

@Local
public interface UpravljalecUgodnostiSBLocal {
	
	 public void dodajUgodnost(Ugodnost ugodnost);
	 
	 public Ugodnost vrniUgodnost(String naziv);
	 
	 public void odstraniUgodnostPoNazivu(String naziv);
	 
	 public List<Ugodnost> vseUgodnosti();
}
