package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.Local;

import si.fri.prpo.jpa.ZbraneTocke;

@Local
public interface UpravljalecZbranihTockSBLocal {
	
	public void dodajTocke(ZbraneTocke tocke);
	
	public ZbraneTocke vrniTocke(int id);
	
	public ZbraneTocke vrniTocke(long idPonudnika, long idStranke);
	
	public void spremeniSteviloTock(int stevilo, ZbraneTocke tocke);
	
	public List<ZbraneTocke> vseZbraneTocke();
	
	//public void odstejTocke(ZbraneTocke tocke, int st);
	
}
