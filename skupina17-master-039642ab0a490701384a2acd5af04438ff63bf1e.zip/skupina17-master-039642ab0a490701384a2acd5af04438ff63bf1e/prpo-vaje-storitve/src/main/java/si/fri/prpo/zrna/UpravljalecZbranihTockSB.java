package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;

/**
 * Session Bean implementation class UpravljalecZbranihTockSB
 */
@Stateless
@LocalBean
public class UpravljalecZbranihTockSB implements UpravljalecZbranihTockSBRemote, UpravljalecZbranihTockSBLocal {
	
    /**
     * Default constructor. 
     */
    public UpravljalecZbranihTockSB() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext
	EntityManager em;
	@Override
    public void dodajTocke(ZbraneTocke tocke) {
		em.persist(tocke);
    }
	
	@Override
	public ZbraneTocke vrniTocke(long idPonudnika, long idStranke) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<ZbraneTocke> c = cb.createQuery(ZbraneTocke.class);
		Root<ZbraneTocke> zt = c.from(ZbraneTocke.class);
		c.select(zt).where(cb.equal(zt.get("ponudnikBean"), idPonudnika)).where(cb.equal(zt.get("strankaBean"), idStranke));
		ZbraneTocke zbraneTocke = em.createQuery(c).getSingleResult();
		return zbraneTocke;
	}
	
	@Override
	public ZbraneTocke vrniTocke(int id) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<ZbraneTocke> c = cb.createQuery(ZbraneTocke.class);
		Root<ZbraneTocke> zt = c.from(ZbraneTocke.class);
		c.select(zt).where(cb.equal(zt.get("id"), id));
		ZbraneTocke zbraneTocke = em.createQuery(c).getSingleResult();
		return zbraneTocke;
	}
	
	@Override
	public void spremeniSteviloTock(int stevilo, ZbraneTocke tocke) {
		/*CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaUpdate<ZbraneTocke> update = cb.createCriteriaUpdate(ZbraneTocke.class);
		CriteriaQuery<ZbraneTocke> c = cb.createQuery(ZbraneTocke.class);
		Root<ZbraneTocke> zt = update.from(ZbraneTocke.class);
		update.set("stevilotock", (tocke.getSteviloTock() + stevilo));
		update.where(cb.equal(zt.get("id"), tocke.getId()));
		em.createQuery(update).executeUpdate();*/
		tocke.setSteviloTock(tocke.getSteviloTock()+stevilo);
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ZbraneTocke> vseZbraneTocke(){
		return (List<ZbraneTocke>) em.createNamedQuery("ZbraneTocke.findAll").getResultList();
	}
}
