package si.fri.prpo.zrna;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.ZbraneTocke;

/**
 * Session Bean implementation class UpravljalecKoriscenjaUgodnosti
 */
@Stateless
public class UpravljalecKoriscenjaUgodnosti implements UpravljalecKoriscenjaUgodnostiRemote, UpravljalecKoriscenjaUgodnostiLocal {

    /**
     * Default constructor. 
     */
	
	@EJB 
	UpravljalecStrankSBLocal upStrank;
	@EJB 
	UpravljalecZbranihTockSBLocal upTock;
	@EJB 
	UpravljalecUgodnostiSBLocal upUgodnosti;
	@EJB
	UpravljalecPonudnikovSBLocal upPonudnikov;
	
    public UpravljalecKoriscenjaUgodnosti() {
        // TODO Auto-generated constructor stub
    }
    
    public void koristiUgodnost() {
    	
    }
    
    public Stranka vrniStranko(int id) {
    	return upStrank.vrniStranko(id);
    }
    
   public Ponudnik vrniPonudnika(int id) {
	   return upPonudnikov.vrniPonudnika(id);
   }
   
   public ZbraneTocke vrniTocke(long idPonudnika, long idStranke) {
	  return upTock.vrniTocke(idPonudnika, idStranke); 
   }
    
}
