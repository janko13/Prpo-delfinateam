package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;

/**
 * Session Bean implementation class UpravljalecPonudnikovSB
 */
@Stateless
@LocalBean
public class UpravljalecPonudnikovSB implements UpravljalecPonudnikovSBRemote, UpravljalecPonudnikovSBLocal {

    /**
     * Default constructor. 
     */
    public UpravljalecPonudnikovSB() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext
	EntityManager em;
	@Override
	public void shraniNovegaPonudnika(Ponudnik ponudnik) {
		em.persist(ponudnik);
	}
	
	@Override
	public Ponudnik vrniPonudnika(String naziv) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Ponudnik> c = cb.createQuery(Ponudnik.class);
		Root<Ponudnik> po = c.from(Ponudnik.class);
		c.select(po).where(cb.equal(po.get("naziv"), naziv));
		Ponudnik ponudnik = em.createQuery(c).getSingleResult();
		return ponudnik;
	}
	
	public Ponudnik vrniPonudnika(int id) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Ponudnik> c = cb.createQuery(Ponudnik.class);
		Root<Ponudnik> po = c.from(Ponudnik.class);
		c.select(po).where(cb.equal(po.get("id"), id));
		Ponudnik ponudnik = em.createQuery(c).getSingleResult();
		return ponudnik;
    }
	
	@Override
	public void odstraniPonudnika(String naziv) {
		Ponudnik ponudnik = vrniPonudnika(naziv);
		em.remove(ponudnik);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Ponudnik> vrniVsePonudnike() {
		return (List<Ponudnik>) em.createNamedQuery("Ponudnik.findAll").getResultList();
	}

}
