
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;
import si.fri.prpo.zrna.UpravljalecPonudnikovSBLocal;
import si.fri.prpo.zrna.UpravljalecStrankSB;
import si.fri.prpo.zrna.UpravljalecStrankSBLocal;
import si.fri.prpo.zrna.UpravljalecUgodnostiSBLocal;
import si.fri.prpo.zrna.UpravljalecZbranihTockSBLocal;

/**
 * Servlet implementation class EJBTestingServlet
 */
public class EJBTestingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	@EJB 
	UpravljalecStrankSBLocal upStrank;
	@EJB 
	UpravljalecZbranihTockSBLocal upTock;
	@EJB 
	UpravljalecUgodnostiSBLocal upUgodnosti;
	@EJB
	UpravljalecPonudnikovSBLocal upPonudnikov;
    //@EJB(beanName="UpravljalecStrankSBLocal")
	@PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction ut;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EJBTestingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter outprint = response.getWriter();
		
		outprint.println("\n");
		
		try {

			upStrank.odstraniStranko("u2");

		} catch  (Exception e) {
			
			e.printStackTrace();
		}
		
		//izpise seznam strank
		List<Stranka> stranke = upStrank.vrniVseStranke();
		outprint.println("\nSeznam strank: ");
		for (Stranka s: stranke) {
			outprint.println("Stranka: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		
		//izpise stranko
		Stranka st = upStrank.vrniStranko("spelca");
		outprint.println("\nStranka z uporabniskim imenom spelca ima priimek " + st.getPriimek());
		
		Stranka st2 = upStrank.vrniStranko(3);
		outprint.println("\nStranka z id 3 ima priimek " + st2.getIme());
		
		/*Stranka s = new Stranka();
		s.setIme("ui4");
		s.setPriimek("up4");
		s.setUporabniskoIme("u4");
		upStrank.shraniNovoStranko(s);*/
		
		ZbraneTocke zt2 = upTock.vrniTocke(3);
		upTock.spremeniSteviloTock(50, zt2);
		
		List<ZbraneTocke> tocke = upTock.vseZbraneTocke();
		outprint.println("\nSeznam tock: ");
		for (ZbraneTocke t: tocke) {
			outprint.println("stranka: " + t.getStrankaBean().getIme() + " ima pri ponudniku " + t.getPonudnikBean().getNaziv() + " " +t.getSteviloTock() + " tock.");
		}
		
		ZbraneTocke zt = upTock.vrniTocke(3);
		outprint.println("\nTocke, ki imajo id 3 pripadajo stranki z imenom " + zt.getStrankaBean().getIme());
		

		
		//izpise stevilo tock, ki jih more imeti stranka, ce zeli pri dolocenem ponudniku dobiti darilo
		Ugodnost u = upUgodnosti.vrniUgodnost("darilo");
		outprint.println("\nStranke lahko dobijo pri ponudniku " + u.getPonudnikBean().getNaziv() + " darilo, ce zberejo " + u.getSteviloPotrebnihTock() + " tock.");
		
		//izpise naslov ponudnika z določenim uporabniski imenom
		String naziv = u.getPonudnikBean().getNaziv();
		Ponudnik p = upPonudnikov.vrniPonudnika(naziv);
		outprint.println("\nPoudnik " + u.getPonudnikBean().getNaziv() + " ima skladisce na naslovu " + p.getLokacija() + ".");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
