

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import si.fri.prpo.jpa.Stranka;



/**
 * Servlet implementation class JPA_servlet
 */
public class JPA_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JPA_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @PersistenceContext
    //@PersistenceContext(unitName="prpo-vaje-jpa")
    EntityManager em;
    @Resource
    UserTransaction ut;
    
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	response.getWriter().append("Served at: ").append(request.getContextPath());
    	//EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		//EntityManager em = emf.createEntityManager();
    	
    	PrintWriter outprint = response.getWriter();
    	Query q;
		outprint.println("\n");
    	
    	int stZapisov = 2;
    	int zacetek = 0;
    	
    	/** SELECT with paging **/
    	while(true) {
    		outprint.println("\nNov paket.");
    		q = em.createQuery("SELECT s FROM Stranka s");
    		q.setMaxResults(stZapisov);
    		q.setFirstResult(zacetek);
    		List<Stranka> stranke = (List<Stranka>)(q.getResultList());
    		if(stranke.isEmpty()){
    			break;
    		}	
    		for (Stranka s: stranke) {
    			outprint.println("Stranka: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
    		}
    		em.clear();
    		zacetek += stranke.size();
    	}
    	
		q = em.createNamedQuery("Stranka.findAll");
		List<Stranka> stranke = (List<Stranka>)(q.getResultList());
		for (Stranka s: stranke) {
			outprint.println("Stranka: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		em.clear();
		
		/**Testing NamedQueries **/
		outprint.println("\n");
		q = em.createNamedQuery("Stranka.findByName").setParameter("sName", "ui1");
		stranke = (List<Stranka>) (q.getResultList());
		for (Stranka s: stranke) {
			outprint.println("Stranka po imenu: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		outprint.println("\n");
		q = em.createNamedQuery("Stranka.findByLastname").setParameter("sLastname", "up1");
		stranke = (List<Stranka>) (q.getResultList());
		for (Stranka s: stranke) {
			outprint.println("Stranka po priimku: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		outprint.println("\n");
		q = em.createNamedQuery("Stranka.findByEmail").setParameter("sEmail", "ue1");
		stranke = (List<Stranka>) (q.getResultList());
		for (Stranka s: stranke) {
			outprint.println("Stranka po emailu: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		
		/** UPDATE **/
		try{
			ut.begin();
			Stranka s = em.find(Stranka.class, 1L);
			//outprint.println("tukaj");
			//em.getTransaction().begin();
			s.setEmail("newEmail");
			//em.getTransaction().commit();
			ut.commit();
			outprint.println("UPDATE: Stranka: " + s.getIme() + " " + s.getPriimek() + " z emailom: " + s.getEmail());
		} catch  (Exception e) {
			e.printStackTrace();
		}
		
		/** DELETE **/
		try {
			ut.begin();
			Stranka s = em.find(Stranka.class, 1L);
			em.remove(s);
			ut.commit();
			outprint.println("\nNov seznam strank:");
			q = em.createNamedQuery("Stranka.findAll");
			stranke = (List<Stranka>)(q.getResultList());
			for (Stranka st: stranke) {
				outprint.println("Stranka: " + st.getIme() + " " + st.getPriimek() + " z uporabniskim imenom " + st.getUporabniskoIme());
			}
			em.clear();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
