
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import si.fri.prpo.Entiteta;
import si.fri.prpo.Stranka;
import si.fri.prpo.StrankaEntitetaDaoImpl;

/**
 * Servlet implementation class TestJDBCServlet
 */
public class TestJDBCServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public TestJDBCServlet() {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//System.out.println("test");
		
		StrankaEntitetaDaoImpl strankaNova = new StrankaEntitetaDaoImpl();
		List<Entiteta> stranka = strankaNova.vrniVse();
		
		response.setContentType("text/html");
		PrintWriter outprint = response.getWriter();
		outprint.println("<title>Stranke v aplikaciji Zvestoba:</title>");
		outprint.println("<h1>Stranke v aplikaciji Zvestoba:</h1>");
		for(Entiteta entiteta : stranka)	outprint.println("<br>" + ((Stranka)entiteta).toString() + "</br>");
		
		System.out.println("Stranke v aplikaciji Zvestoba:");
		for(Entiteta entiteta : stranka)	System.out.println(((Stranka)entiteta).toString());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
