package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.Local;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;

@Local
public interface UpravljalecKoriscenjaUgodnostiLocal {

	public boolean koriscenjeTock(long idStranke, long idPonudnika, long idUgodnosti) throws NeveljavenZahtevekException;
	
	public Stranka vrniStranko(long id);
	
	public Ponudnik vrniPonudnika(long id);
	
	public ZbraneTocke vrniTocke(long idPonudnika, long idStranke);
	
	public Ugodnost vrniUgodnost(long idUgodnosti);
	
	public boolean ugodnostPriPonudniku(long idPonudnika, long idUgodnosti);
	
	public void koristiUgodnost(long idStranke, long idUgodnosti) throws NeveljavenZahtevekException;
}
