package si.fri.prpo.zrna;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class NeveljavenZahtevekException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NeveljavenZahtevekException(String message){
       super(message);
       System.out.println(message);
    }
}
