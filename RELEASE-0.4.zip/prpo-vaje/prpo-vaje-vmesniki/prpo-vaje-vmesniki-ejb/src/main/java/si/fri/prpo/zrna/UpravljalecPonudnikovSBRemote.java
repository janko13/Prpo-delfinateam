package si.fri.prpo.zrna;

import javax.ejb.Remote;

@Remote
public interface UpravljalecPonudnikovSBRemote {

}
