
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.RunAs;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;
import si.fri.prpo.zrna.NeveljavenZahtevekException;
import si.fri.prpo.zrna.UpravljalecKoriscenjaUgodnosti;
import si.fri.prpo.zrna.UpravljalecKoriscenjaUgodnostiLocal;
import si.fri.prpo.zrna.UpravljalecPonudnikovSBLocal;
import si.fri.prpo.zrna.UpravljalecStrankSB;
import si.fri.prpo.zrna.UpravljalecStrankSBLocal;
import si.fri.prpo.zrna.UpravljalecUgodnostiSBLocal;
import si.fri.prpo.zrna.UpravljalecZbranihTockSBLocal;

/**
 * Servlet implementation class EJBTestingServlet
 */
public class EJBTestingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	@EJB 
	UpravljalecStrankSBLocal upStrank;
	@EJB 
	UpravljalecZbranihTockSBLocal upTock;
	@EJB 
	UpravljalecUgodnostiSBLocal upUgodnosti;
	@EJB
	UpravljalecPonudnikovSBLocal upPonudnikov;
	@EJB
	UpravljalecKoriscenjaUgodnostiLocal upKoriscenjaUgodnosti;
    //@EJB(beanName="UpravljalecStrankSBLocal")
	@PersistenceContext
    EntityManager em;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EJBTestingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter outprint = response.getWriter();
		outprint.println("\n");
		
		outprint.println("Stranka zeli koristiti ugodnost pri danem ponudniku. Ima za to dovolj tock?");
		try{
			boolean lahkoKoristi = upKoriscenjaUgodnosti.koriscenjeTock(3L, 1L, 1L);
			if (lahkoKoristi) {
				outprint.println("Stranka ima dovolj tock.");
			} else {
				outprint.println("Nekaj je slo narobe. Preveri, da obstajajo stranka, ponudnik in ugodnost in stevilo tock, ki jih ugodnost pri ponudniku zahteva.");
			}
		} catch(NeveljavenZahtevekException nz) {
			nz.printStackTrace();
		}
		/*outprint.println("Stranka zeli koristiti ugodnost pri danem ponudniku. Ima za to dovolj tock?");
		lahkoKoristi = upKoriscenjaUgodnosti.koriscenjeTock(3L, 1L, 1L);
		if (lahkoKoristi) {
			outprint.println("Stranka ima dovolj tock.");
		} else {
			outprint.println("Stranka nima dovolj tock.");
		}*/
		
		
		try {
			upKoriscenjaUgodnosti.koristiUgodnost(5L, 2L);
			//throw new RuntimeException();
		} catch(NeveljavenZahtevekException nz) {
			nz.printStackTrace();
		}
		/*
		try {

			upStrank.odstraniStranko("u0");

		} catch  (Exception e) {
			
			e.printStackTrace();
		}
		
		try {
			Stranka s = new Stranka();
			s.setIme("ui2");
			s.setPriimek("up2");
			s.setUporabniskoIme("u2");
			s.setEmail("email!!!!");
			s.setId(6);
			upStrank.shraniNovoStranko(s);
		} catch  (Exception e) {
			e.printStackTrace();
		}
		
		//izpise seznam strank
		List<Stranka> stranke = upStrank.vrniVseStranke();
		outprint.println("\nSeznam strank: ");
		for (Stranka s: stranke) {
			outprint.println("Stranka: " + s.getIme() + " " + s.getPriimek() + " z uporabniskim imenom " + s.getUporabniskoIme());
		}
		
		//izpise stranko
		Stranka st = upStrank.vrniStranko("spelca");
		outprint.println("\nStranka z uporabniskim imenom spelca ima priimek " + st.getPriimek());
		
		Stranka st2 = upStrank.vrniStranko(3);
		outprint.println("\nStranka z id 3 ima priimek " + st2.getIme());
		
		//spreminjanje stevila tock
		try {
			upTock.spremeniSteviloTock(50, 5);
		} catch  (Exception e) {
			outprint.println("\n ni spremenilo tock");
			e.printStackTrace();
		}
		
		//dodajanje tock 
		try {
			ZbraneTocke tocke = new ZbraneTocke();
			tocke.setPonudnikBean(upPonudnikov.vrniPonudnika(1));
			tocke.setStrankaBean(upStrank.vrniStranko(2));
			tocke.setSteviloTock(30);
			upTock.dodajTocke(tocke);
		} catch (Exception e){
			e.printStackTrace();
		}
		
		
		List<ZbraneTocke> tocke = upTock.vseZbraneTocke();
		outprint.println("\nSeznam tock: ");
		for (ZbraneTocke t: tocke) {
			outprint.println("stranka: " + t.getStrankaBean().getIme() + " ima pri ponudniku " + t.getPonudnikBean().getNaziv() + " " +t.getSteviloTock() + " tock.");
		}
		
		ZbraneTocke zt = upTock.vrniTocke(3);
		outprint.println("\nTocke, ki imajo id 3 pripadajo stranki z imenom " + zt.getStrankaBean().getIme());
		

		
		//izpise stevilo tock, ki jih more imeti stranka, ce zeli pri dolocenem ponudniku dobiti darilo
		Ugodnost u = upUgodnosti.vrniUgodnost("darilo");
		outprint.println("\nStranke lahko dobijo pri ponudniku " + u.getPonudnikBean().getNaziv() + " darilo, ce zberejo " + u.getSteviloPotrebnihTock() + " tock.");
		
		//izpise naslov ponudnika z določenim uporabniski imenom
		String naziv = u.getPonudnikBean().getNaziv();
		Ponudnik p = upPonudnikov.vrniPonudnika(naziv);
		outprint.println("\nPoudnik " + u.getPonudnikBean().getNaziv() + " ima skladisce na naslovu " + p.getLokacija() + ".");
		*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Resource
	UserTransaction ut;

}
