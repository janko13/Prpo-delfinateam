package si.fri.prpo.zrna;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.annotation.security.RunAs;
import javax.ejb.EJB;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;

/**
 * Session Bean implementation class UpravljalecKoriscenjaUgodnosti
 */
@Stateless
@LocalBean
@DeclareRoles({"Uporabniki", "Administrator", "Gost"})
@RunAs("Uporabnik")
public class UpravljalecKoriscenjaUgodnosti implements UpravljalecKoriscenjaUgodnostiRemote, UpravljalecKoriscenjaUgodnostiLocal {

    /**
     * Default constructor. 
     */
	
	@EJB 
	UpravljalecStrankSBLocal upStrank;
	@EJB 
	UpravljalecZbranihTockSBLocal upTock;
	@EJB 
	UpravljalecUgodnostiSBLocal upUgodnosti;
	@EJB
	UpravljalecPonudnikovSBLocal upPonudnikov;
	
    public UpravljalecKoriscenjaUgodnosti(){
    	// TODO Auto-generated constructor stub
    }
    
    @Override
    @PermitAll
    public boolean koriscenjeTock(long idStranke, long idPonudnika, long idUgodnosti) throws NeveljavenZahtevekException {
    	try {
    		if (vrniStranko(idStranke) != null && vrniPonudnika(idPonudnika) != null
    			&& vrniUgodnost(idUgodnosti) != null) {
				if (ugodnostPriPonudniku(idPonudnika, idUgodnosti)) {
					if (vrniTocke(idPonudnika, idStranke).getSteviloTock() >= vrniUgodnost(idUgodnosti).getSteviloPotrebnihTock()) {
						return true;
					} else {
						throw new NeveljavenZahtevekException("Uporabnik nima dovolj tock!");
					}
				} else {
					throw new NeveljavenZahtevekException("Ponudnik nima zeljene ugodnosti!");
				}
			} else {
				throw new NeveljavenZahtevekException("Stranka, ponudnik ali ugodnost ne obstaja!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
    
    
    
    @Resource
    private EJBContext kontekstZrna;
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    @PermitAll
    public void koristiUgodnost(long idStranke, long idUgodnosti) throws NeveljavenZahtevekException{
    	Ugodnost ugodnost = vrniUgodnost(idUgodnosti);
    	Ponudnik ponudnik = vrniPonudnika(ugodnost.getPonudnikBean().getId());
    	long idPonudnika = ponudnik.getId();
    	
    	if (koriscenjeTock(idStranke, idPonudnika, idUgodnosti)) {
    		long idTock = vrniTocke(idPonudnika, idStranke).getId();
        	int potrebnihTock = ugodnost.getSteviloPotrebnihTock();
        	upTock.spremeniSteviloTock(-potrebnihTock, idTock);
    	} else {
    		kontekstZrna.setRollbackOnly();
    	}
    	
    	//kontekstZrna.getRollbackOnly();
    }
    
    @Override
    @RolesAllowed("Uporabnik")
    public Stranka vrniStranko(long id) {
    	return upStrank.vrniStranko(id);
    }
    
    @Override
    @RolesAllowed("Uporabnik")
    public Ponudnik vrniPonudnika(long idPonudnika) {
    	return upPonudnikov.vrniPonudnika(idPonudnika);
    }
   
    @Override
    @RolesAllowed("Uporabnik")
    public ZbraneTocke vrniTocke(long idPonudnika, long idStranke) {
    	return upTock.vrniTocke(idPonudnika, idStranke); 
    }
   
    @Override
    @RolesAllowed("Uporabnik")
    public Ugodnost vrniUgodnost(long idUgodnosti) {
    	return upUgodnosti.vrniUgodnost(idUgodnosti);
    }
   
    @Override
    @RolesAllowed("Uporabnik")
    public boolean ugodnostPriPonudniku(long idPonudnika, long idUgodnosti) {
    	if (vrniUgodnost(idUgodnosti).getPonudnikBean().getId() == idPonudnika) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
}
