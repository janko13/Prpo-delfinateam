package si.fri.prpo.zrna;

import java.io.PrintWriter;
import java.util.List;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.annotation.security.RunAs;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;
import si.fri.prpo.jpa.ZbraneTocke;

/**
 * Session Bean implementation class UpravljalecZbranihTockSB
 */
@Stateless
@LocalBean
public class UpravljalecZbranihTockSB implements UpravljalecZbranihTockSBRemote, UpravljalecZbranihTockSBLocal {
	
    /**
     * Default constructor. 
     */
    public UpravljalecZbranihTockSB() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext
	EntityManager em;
	@Override
    public void dodajTocke(ZbraneTocke tocke) {
		em.persist(tocke);
		em.flush();
    }
	
	@Override
	public ZbraneTocke vrniTocke(long idPonudnika, long idStranke) {
		try {
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<ZbraneTocke> c = cb.createQuery(ZbraneTocke.class);
			Root<ZbraneTocke> zt = c.from(ZbraneTocke.class);
			c.select(zt).where(cb.equal(zt.get("ponudnikBean"), idPonudnika)).where(cb.equal(zt.get("strankaBean"), idStranke));
			ZbraneTocke zbraneTocke = em.createQuery(c).getSingleResult();
			return zbraneTocke;
		} catch(NoResultException e) {
			return null;
		}	
	}
	
	@Override
	@RolesAllowed("Uporabnik")
	public ZbraneTocke vrniTocke(long id) {
		try{
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<ZbraneTocke> c = cb.createQuery(ZbraneTocke.class);
			Root<ZbraneTocke> zt = c.from(ZbraneTocke.class);
			c.select(zt).where(cb.equal(zt.get("id"), id));
			ZbraneTocke zbraneTocke = em.createQuery(c).getSingleResult();
			return zbraneTocke;
		} catch(NoResultException e) {
			return null;
		}
	}
	
	@Override
	public void spremeniSteviloTock(int stevilo, long idTock) {
		ZbraneTocke tocke = vrniTocke(idTock);
		if(tocke!=null){
			tocke.setSteviloTock(tocke.getSteviloTock() + stevilo);
			em.merge(tocke);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ZbraneTocke> vseZbraneTocke(){
		return (List<ZbraneTocke>) em.createNamedQuery("ZbraneTocke.findAll").getResultList();
	}
}
