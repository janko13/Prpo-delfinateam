package si.fri.prpo.zrna;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

import si.fri.prpo.jpa.Stranka;

/**
 * Session Bean implementation class UpravljalecStrankSB
 */
@Stateless
@LocalBean
public class UpravljalecStrankSB implements UpravljalecStrankSBRemote, UpravljalecStrankSBLocal {

    /**
     * Default constructor. 
     */
    public UpravljalecStrankSB() {
        // TODO Auto-generated constructor stub
    }

	@PersistenceContext
	EntityManager em;
	 
	@Override
	public void shraniNovoStranko(Stranka stranka) {
		em.persist(stranka);
		em.clear();
    }
	
	@Override
	public Stranka vrniStranko(String uporabniskoIme) {
		try{
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Stranka> c = cb.createQuery(Stranka.class);
			Root<Stranka> st = c.from(Stranka.class);
			c.select(st).where(cb.equal(st.get("uporabniskoIme"), uporabniskoIme));
			Stranka stranka = em.createQuery(c).getSingleResult();
			return stranka;
		} catch(NoResultException e) {
			return null;
		}
	}
	
	@Override
	public Stranka vrniStranko(long id) {
		try{
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Stranka> c = cb.createQuery(Stranka.class);
			Root<Stranka> st = c.from(Stranka.class);
			c.select(st).where(cb.equal(st.get("id"), id));
			Stranka stranka = em.createQuery(c).getSingleResult();
			return stranka;
		} catch(NoResultException e) {
			return null;
		}
	}
	
	@Override
	public void odstraniStranko(String uporabniskoIme){
		Stranka stranka = vrniStranko(uporabniskoIme);
		if(stranka != null){
			em.remove(stranka);
		}
	}
	
	@Override
	public void odstraniStranko(long id) {
		Stranka stranka = vrniStranko(id);
		if(stranka!=null){
			em.remove(stranka);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Stranka> vrniVseStranke() {
		return (List<Stranka>) em.createNamedQuery("Stranka.findAll").getResultList();
	}
}
