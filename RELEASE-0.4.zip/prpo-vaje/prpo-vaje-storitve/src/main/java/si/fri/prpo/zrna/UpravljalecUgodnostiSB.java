package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import si.fri.prpo.jpa.Stranka;
import si.fri.prpo.jpa.Ugodnost;

/**
 * Session Bean implementation class UpravljalecUgodnostiSB
 */
@LocalBean
@Stateless
public class UpravljalecUgodnostiSB implements UpravljalecUgodnostiSBRemote, UpravljalecUgodnostiSBLocal {

    /**
     * Default constructor. 
     */
    public UpravljalecUgodnostiSB() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext
	EntityManager em;
	@Override
    public void dodajUgodnost(Ugodnost ugodnost) {
		em.persist(ugodnost);
    }
	
	@Override
	public Ugodnost vrniUgodnost(String naziv) {
		try {
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Ugodnost> c = cb.createQuery(Ugodnost.class);
			Root<Ugodnost> ug = c.from(Ugodnost.class);
			c.select(ug).where(cb.equal(ug.get("naziv"), naziv));
			Ugodnost ugodnost = em.createQuery(c).getSingleResult();
			return ugodnost;
		} catch(NoResultException e) {
			return null;
		}
	}
	 
	@Override
	public Ugodnost vrniUgodnost(long idUgodnosti) {
		try {
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Ugodnost> c = cb.createQuery(Ugodnost.class);
			Root<Ugodnost> ug = c.from(Ugodnost.class);
			c.select(ug).where(cb.equal(ug.get("id"), idUgodnosti));
			Ugodnost ugodnost = em.createQuery(c).getSingleResult();
			return ugodnost;
		} catch(NoResultException e) {
			return null;
		}
	}
	
	@Override
	public void odstraniUgodnostPoNazivu(String naziv) {
		Ugodnost ugodnost= vrniUgodnost(naziv);
		if(ugodnost!=null){
			em.remove(ugodnost);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Ugodnost> vseUgodnosti(){
		return (List<Ugodnost>) em.createNamedQuery("Ugodnost.findAll").getResultList();
	}

}
