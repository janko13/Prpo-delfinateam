package si.fri.prpo.jpa;
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the zbraneTocke database table.
 * 
 */
@Entity
@Table(name="zbranetocke")
@NamedQuery(name="ZbraneTocke.findAll", query="SELECT z FROM ZbraneTocke z")
public class ZbraneTocke implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;

	@Column(name="stevilotock")
	private int steviloTock;

	//bi-directional many-to-one association to Ponudnik
	@ManyToOne
	@JoinColumn(name="ponudnik", referencedColumnName="id")
	private Ponudnik ponudnikBean;

	//bi-directional many-to-one association to Stranka
	@ManyToOne
	@JoinColumn(name="stranka", referencedColumnName="id")
	private Stranka strankaBean;

	public ZbraneTocke() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getSteviloTock() {
		return this.steviloTock;
	}

	public void setSteviloTock(int steviloTock) {
		this.steviloTock = steviloTock;
	}

	public Ponudnik getPonudnikBean() {
		return this.ponudnikBean;
	}

	public void setPonudnikBean(Ponudnik ponudnikBean) {
		this.ponudnikBean = ponudnikBean;
	}

	public Stranka getStrankaBean() {
		return this.strankaBean;
	}

	public void setStrankaBean(Stranka strankaBean) {
		this.strankaBean = strankaBean;
	}

}