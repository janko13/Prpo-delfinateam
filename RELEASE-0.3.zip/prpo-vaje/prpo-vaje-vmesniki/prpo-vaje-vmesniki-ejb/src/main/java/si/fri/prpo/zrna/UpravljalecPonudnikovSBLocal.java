package si.fri.prpo.zrna;

import java.util.List;

import javax.ejb.Local;

import si.fri.prpo.jpa.Ponudnik;
import si.fri.prpo.jpa.Stranka;

@Local
public interface UpravljalecPonudnikovSBLocal {

	public void shraniNovegaPonudnika(Ponudnik ponudnik);
	
	public Ponudnik vrniPonudnika(String naziv);

	public void odstraniPonudnika(String naziv);
	
	public List<Ponudnik> vrniVsePonudnike();
	
}
